from geometry_package.rectangle import Rectangle
from geometry_package.triangle import Triangle
from geometry_package.trapezoid import Trapezoid
import docx
import openpyxl

# Выбор фреймворка
GUI_FRAMEWORK = 'tkinter'  # Или 'pyforms'

if GUI_FRAMEWORK == 'pyforms':
    from gui_frameworks.pyforms_gui import PyformsGUI as GUI
elif GUI_FRAMEWORK == 'tkinter':
    from gui_frameworks.tkinter_gui import TkinterGUI as GUI

class GeometryApp:
    def __init__(self):
        self.gui = GUI()
        self.gui.set_calculate_callback(self.calculate)
        self.gui.set_save_doc_callback(self.save_to_doc)
        self.gui.set_save_xls_callback(self.save_to_xls)
        self.gui.setup_ui()

    def calculate(self):
        shape = self.gui.get_shape()
        params = [float(p) for p in self.gui.get_params() if p]
        try:
            if shape == 'Rectangle':
                rect = Rectangle(params[0], params[1])
                result = f"Area: {rect.area()}, Circumradius: {rect.circumradius()}, Inradius: {rect.inradius()}"
            elif shape == 'Triangle':
                tri = Triangle(params[0], params[1], params[2])
                result = f"Area: {tri.area()}, Circumradius: {tri.circumradius()}, Inradius: {tri.inradius()}"
            elif shape == 'Trapezoid':
                trap = Trapezoid(params[0], params[1], params[2], params[3])
                result = f"Area: {trap.area()}, Inradius: {trap.inradius()}"
            self.gui.update_result(result)
        except ValueError:
            self.gui.update_result("Invalid input")

    def save_to_doc(self):
        doc = docx.Document()
        doc.add_paragraph(self.gui.result_label.cget('text'))
        doc.save('result.docx')

    def save_to_xls(self):
        wb = openpyxl.Workbook()
        ws = wb.active
        ws['A1'] = self.gui.result_label.cget('text')
        wb.save('result.xlsx')

    def run(self):
        self.gui.run()

if __name__ == "__main__":
    app = GeometryApp()
    app.run()