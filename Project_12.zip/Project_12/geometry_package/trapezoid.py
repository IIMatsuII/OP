import math

class Trapezoid:
    def __init__(self, a, b, c, d):
        self.a = a
        self.b = b
        self.c = c
        self.d = d

    def area(self):
        return 0.5 * (self.a + self.b) * self.height()

    def height(self):
        return math.sqrt(self.c**2 - ((self.b - self.a)**2 + self.c**2 - self.d**2) / (2 * (self.b - self.a))**2)

    def circumradius(self):
        return None  # Для трапеции радиус описанной окружности не всегда определён

    def inradius(self):
        return self.area() / (0.5 * (self.a + self.b + self.c + self.d))