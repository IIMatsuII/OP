from pyforms import BaseWidget
from pyforms.controls import ControlText, ControlButton, ControlLabel, ControlCombo
from gui_frameworks import BaseGUI

class PyformsGUI(BaseGUI, BaseWidget):
    def __init__(self):
        super().__init__('Geometry Calculator')
        self._shape_selector = ControlCombo('Select Shape')
        self._shape_selector.add_item('Rectangle')
        self._shape_selector.add_item('Triangle')
        self._shape_selector.add_item('Trapezoid')

        self._param1 = ControlText('Parameter 1')
        self._param2 = ControlText('Parameter 2')
        self._param3 = ControlText('Parameter 3')
        self._param4 = ControlText('Parameter 4')

        self._calculate_button = ControlButton('Calculate')
        self._result_label = ControlLabel('Result: ')

        self._save_doc_button = ControlButton('Save to .doc')
        self._save_xls_button = ControlButton('Save to .xls')

        self.formset = [
            ('_shape_selector', '_param1', '_param2', '_param3', '_param4'),
            '_calculate_button',
            '_result_label',
            ('_save_doc_button', '_save_xls_button')
        ]

    def setup_ui(self):
        self._shape_selector.changed_event = self.update_ui

    def set_calculate_callback(self, callback):
        self._calculate_button.value = callback

    def set_save_doc_callback(self, callback):
        self._save_doc_button.value = callback

    def set_save_xls_callback(self, callback):
        self._save_xls_button.value = callback

    def update_result(self, result):
        self._result_label.value = f"Result: {result}"

    def get_shape(self):
        return self._shape_selector.value

    def get_params(self):
        return [self._param1.value, self._param2.value, self._param3.value, self._param4.value]

    def update_ui(self):
        shape = self.get_shape()
        if shape == 'Rectangle':
            self._param1.label = 'Width'
            self._param2.label = 'Height'
            self._param3.hide()
            self._param4.hide()
        elif shape == 'Triangle':
            self._param1.label = 'Side A'
            self._param2.label = 'Side B'
            self._param3.label = 'Side C'
            self._param3.show()
            self._param4.hide()
        elif shape == 'Trapezoid':
            self._param1.label = 'Base A'
            self._param2.label = 'Base B'
            self._param3.label = 'Side C'
            self._param4.label = 'Side D'
            self._param3.show()
            self._param4.show()

    def run(self):
        from pyforms import start_app
        start_app(self)