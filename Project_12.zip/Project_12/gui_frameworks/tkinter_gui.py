import tkinter as tk
from tkinter import ttk
from gui_frameworks import BaseGUI

class TkinterGUI(BaseGUI):
    def __init__(self):
        self.root = tk.Tk()
        self.root.title('Geometry Calculator')

        self.shape_var = tk.StringVar()
        self.shape_selector = ttk.Combobox(self.root, textvariable=self.shape_var)
        self.shape_selector['values'] = ('Rectangle', 'Triangle', 'Trapezoid')
        self.shape_selector.current(0)

        self.param1_label = ttk.Label(self.root, text='Parameter 1')
        self.param1_entry = ttk.Entry(self.root)
        self.param2_label = ttk.Label(self.root, text='Parameter 2')
        self.param2_entry = ttk.Entry(self.root)
        self.param3_label = ttk.Label(self.root, text='Parameter 3')
        self.param3_entry = ttk.Entry(self.root)
        self.param4_label = ttk.Label(self.root, text='Parameter 4')
        self.param4_entry = ttk.Entry(self.root)

        self.calculate_button = ttk.Button(self.root, text='Calculate')
        self.result_label = ttk.Label(self.root, text='Result: ')

        self.save_doc_button = ttk.Button(self.root, text='Save to .doc')
        self.save_xls_button = ttk.Button(self.root, text='Save to .xls')

        self.setup_ui()

    def setup_ui(self):
        self.shape_selector.grid(row=0, column=0, columnspan=2)
        self.param1_label.grid(row=1, column=0)
        self.param1_entry.grid(row=1, column=1)
        self.param2_label.grid(row=2, column=0)
        self.param2_entry.grid(row=2, column=1)
        self.param3_label.grid(row=3, column=0)
        self.param3_entry.grid(row=3, column=1)
        self.param4_label.grid(row=4, column=0)
        self.param4_entry.grid(row=4, column=1)
        self.calculate_button.grid(row=5, column=0, columnspan=2)
        self.result_label.grid(row=6, column=0, columnspan=2)
        self.save_doc_button.grid(row=7, column=0)
        self.save_xls_button.grid(row=7, column=1)

        self.shape_selector.bind('<<ComboboxSelected>>', self.update_ui)

    def set_calculate_callback(self, callback):
        self.calculate_button.config(command=callback)

    def set_save_doc_callback(self, callback):
        self.save_doc_button.config(command=callback)

    def set_save_xls_callback(self, callback):
        self.save_xls_button.config(command=callback)

    def update_result(self, result):
        self.result_label.config(text=f"Result: {result}")

    def get_shape(self):
        return self.shape_var.get()

    def get_params(self):
        return [
            self.param1_entry.get(),
            self.param2_entry.get(),
            self.param3_entry.get(),
            self.param4_entry.get()
        ]

    def update_ui(self, event=None):
        shape = self.get_shape()
        if shape == 'Rectangle':
            self.param1_label.config(text='Width')
            self.param2_label.config(text='Height')
            self.param3_label.grid_remove()
            self.param3_entry.grid_remove()
            self.param4_label.grid_remove()
            self.param4_entry.grid_remove()
        elif shape == 'Triangle':
            self.param1_label.config(text='Side A')
            self.param2_label.config(text='Side B')
            self.param3_label.config(text='Side C')
            self.param3_label.grid()
            self.param3_entry.grid()
            self.param4_label.grid_remove()
            self.param4_entry.grid_remove()
        elif shape == 'Trapezoid':
            self.param1_label.config(text='Base A')
            self.param2_label.config(text='Base B')
            self.param3_label.config(text='Side C')
            self.param4_label.config(text='Side D')
            self.param3_label.grid()
            self.param3_entry.grid()
            self.param4_label.grid()
            self.param4_entry.grid()

    def run(self):
        self.root.mainloop()