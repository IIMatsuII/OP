from abc import ABC, abstractmethod

class BaseGUI(ABC):
    @abstractmethod
    def setup_ui(self):
        pass

    @abstractmethod
    def set_calculate_callback(self, callback):
        pass

    @abstractmethod
    def set_save_doc_callback(self, callback):
        pass

    @abstractmethod
    def set_save_xls_callback(self, callback):
        pass

    @abstractmethod
    def update_result(self, result):
        pass

    @abstractmethod
    def get_shape(self):
        pass

    @abstractmethod
    def get_params(self):
        pass

    @abstractmethod
    def run(self):
        pass