class DivisorFinder:
    """
    Класс для поиска чисел с ровно двумя делителями в заданном диапазоне.
    """
    def __init__(self, start, end):
        self.start = start
        self.end = end

    def is_prime(self, n):
        """
        Проверяет, является ли число простым.
        """
        if n < 2:
            return False
        for i in range(2, int(n**0.5) + 1):
            if n % i == 0:
                return False
        return True

    def find_numbers(self):
        """
        Возвращает список чисел с ровно двумя делителями в диапазоне.
        """
        result = []
        for number in range(self.start, self.end + 1):
            if self.is_prime(number):
                result.append((number, [1, number]))
        return result


# Пример использования
if __name__ == "__main__":
    start = 174457
    end = 174505
    finder = DivisorFinder(start, end)
    result = finder.find_numbers()
    for number, divisors in result:
        print(f"Число: {number}, Делители: {divisors}")