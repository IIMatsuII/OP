from task1 import CodeGenerator
from task2 import BinaryCounter
from task3 import DivisorFinder

def main():
    # Задача 1
    letters = ['Т', 'И', 'М', 'О', 'Ф', 'Е', 'Й']
    length = 5
    generator = CodeGenerator(letters, length)
    print(f"Количество допустимых кодов: {generator.generate_codes()}")

    # Задача 2
    expression = 4**2020 + 2**2017 - 15
    counter = BinaryCounter(expression)
    print(f"Количество единиц в двоичной записи: {counter.count_ones()}")

    # Задача 3
    start = 174457
    end = 174505
    finder = DivisorFinder(start, end)
    result = finder.find_numbers()
    print("Числа с двумя делителями:")
    for number, divisors in result:
        print(f"Число: {number}, Делители: {divisors}")


if __name__ == "__main__":
    main()