class BinaryCounter:
    """
    Класс для подсчёта количества единиц в двоичной записи выражения.
    """
    def __init__(self, expression):
        self.expression = expression

    def count_ones(self):
        """
        Возвращает количество единиц в двоичной записи выражения.
        """
        binary = bin(self.expression)
        return binary.count('1')


# Пример использования
if __name__ == "__main__":
    expression = 4**2020 + 2**2017 - 15
    counter = BinaryCounter(expression)
    print(f"Количество единиц в двоичной записи: {counter.count_ones()}")