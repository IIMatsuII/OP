import itertools

class CodeGenerator:
    """
    Класс для генерации 5-буквенных кодов с ограничениями на букву Й.
    """
    def __init__(self, letters, length):
        self.letters = letters
        self.length = length

    def is_valid(self, code):
        """
        Проверяет, удовлетворяет ли код условиям задачи.
        """
        if code.count('Й') > 1:
            return False
        if 'Й' in code:
            idx = code.index('Й')
            if idx == 0 or idx == self.length - 1:  # Й не может быть на первом или последнем месте
                return False
            if idx > 0 and code[idx - 1] == 'И':  # Й не может быть рядом с И
                return False
            if idx < self.length - 1 and code[idx + 1] == 'И':
                return False
        return True

    def generate_codes(self):
        """
        Генерирует все возможные коды и возвращает количество допустимых.
        """
        valid_codes = []
        for code in itertools.product(self.letters, repeat=self.length):
            if self.is_valid(code):
                valid_codes.append(code)
        return len(valid_codes)


# Пример использования
if __name__ == "__main__":
    letters = ['Т', 'И', 'М', 'О', 'Ф', 'Е', 'Й']
    length = 5
    generator = CodeGenerator(letters, length)
    print(f"Количество допустимых кодов: {generator.generate_codes()}")