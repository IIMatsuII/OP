import pytest
from main import count_elements_iterative, count_elements_recursive, calculate_sequence_iterative, calculate_sequence_recursive

def test_count_elements_iterative():
    assert count_elements_iterative([]) == 0
    assert count_elements_iterative([1, 2, 3]) == 3
    assert count_elements_iterative(["x", "y", ["z"]]) == 4
    assert count_elements_iterative([1, 2, [3, 4, [5]]]) == 7

def test_count_elements_recursive():
    assert count_elements_recursive([]) == 0
    assert count_elements_recursive([1, 2, 3]) == 3
    assert count_elements_recursive(["x", "y", ["z"]]) == 4
    assert count_elements_recursive([1, 2, [3, 4, [5]]]) == 7

def test_calculate_sequence_iterative():
    assert calculate_sequence_iterative(1) == 1
    assert calculate_sequence_iterative(2) == -1/8
    assert calculate_sequence_iterative(3) == pytest.approx(-0.20833333333333334)
    assert calculate_sequence_iterative(4) == pytest.approx(-0.15625)

def test_calculate_sequence_recursive():
    assert calculate_sequence_recursive(1) == 1
    assert calculate_sequence_recursive(2) == -1/8
    assert calculate_sequence_recursive(3) == pytest.approx(-0.20833333333333334)
    assert calculate_sequence_recursive(4) == pytest.approx(-0.15625)