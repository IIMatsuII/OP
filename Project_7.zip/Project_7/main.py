from functools import lru_cache

# Задача 1: Подсчёт элементов в списках

def count_elements_iterative(lst):
    """
    Подсчитывает количество элементов в списке, включая вложенные списки (без рекурсии).
    """
    count = 0
    stack = [lst]
    while stack:
        current = stack.pop()
        for item in current:
            if isinstance(item, list):
                stack.append(item)
            count += 1
    return count


def count_elements_recursive(lst):
    """
    Подсчитывает количество элементов в списке, включая вложенные списки (с рекурсией).
    """
    count = 0
    for item in lst:
        if isinstance(item, list):
            count += count_elements_recursive(item)
        count += 1
    return count


# Задача 2: Расчёт последовательности

def calculate_sequence_iterative(n):
    """
    Вычисляет n-й элемент последовательности (без рекурсии).
    """
    if n == 1:
        return 1
    if n == 2:
        return -1/8
    x_prev_prev = 1
    x_prev = -1/8
    for i in range(3, n + 1):
        x_current = ((i - 1) * x_prev) / 3 + ((i - 2) * x_prev_prev) / 4
        x_prev_prev, x_prev = x_prev, x_current
    return x_prev


@lru_cache(maxsize=None)
def calculate_sequence_recursive(n):
    """
    Вычисляет n-й элемент последовательности (с рекурсией и мемоизацией).
    """
    if n == 1:
        return 1
    if n == 2:
        return -1/8
    return ((n - 1) * calculate_sequence_recursive(n - 1)) / 3 + ((n - 2) * calculate_sequence_recursive(n - 2)) / 4


# Пример использования
if __name__ == "__main__":
    # Пример для задачи 1
    print("Задача 1:")
    print("Итеративная функция:", count_elements_iterative([1, 2, [3, 4, [5]]]))  # Ожидаемый результат: 7
    print("Рекурсивная функция:", count_elements_recursive([1, 2, [3, 4, [5]]]))  # Ожидаемый результат: 7

    # Пример для задачи 2
    print("\nЗадача 2:")
    print("Итеративная функция (n=4):", calculate_sequence_iterative(4))  # Ожидаемый результат: -0.15625
    print("Рекурсивная функция (n=4):", calculate_sequence_recursive(4))  # Ожидаемый результат: -0.15625